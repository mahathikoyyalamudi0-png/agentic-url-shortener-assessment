from __future__ import annotations
from dataclasses import dataclass

@dataclass
class GateResult:
    allowed: bool
    reason: str
    approval_required: bool = False

class PolicyGuard:
    BLOCKED_HOSTS = {"localhost", "127.0.0.1", "169.254.169.254"}

    def check(self, action: str, context: dict) -> GateResult:
        if action in {"release", "schema_change", "production_delete"} and not context.get("human_approved"):
            return GateResult(False, f"Human approval required for {action}", True)
        if context.get("security_findings", 0) > 0:
            return GateResult(False, "Security findings must be remediated before release")
        if context.get("test_failures", 0) > 0:
            return GateResult(False, "Tests must pass before release")
        return GateResult(True, "Policy checks passed")

    def validate_target(self, host: str) -> GateResult:
        if host.lower() in self.BLOCKED_HOSTS:
            return GateResult(False, "Target host is blocked by SSRF policy")
        return GateResult(True, "Target host allowed")
