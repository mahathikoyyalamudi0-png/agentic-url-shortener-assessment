from fastapi import FastAPI, HTTPException, Response
from pydantic import BaseModel, HttpUrl
from .store import UrlStore
from .url_service import UrlService
from .governance import PolicyGuard
from .orchestrator import AgenticOrchestrator
from .scenarios import greenfield_stages, brownfield_stages, ambiguous_stages

app = FastAPI(title="Agentic URL Shortener", version="1.0.0")
store = UrlStore(); service = UrlService(store); orchestrator = AgenticOrchestrator(PolicyGuard())

class CreateUrl(BaseModel):
    url: HttpUrl
    alias: str | None = None

@app.get("/health")
def health(): return {"status":"UP"}

@app.post("/api/v1/urls", status_code=201)
def create(req: CreateUrl):
    try:
        r = service.create(str(req.url), req.alias)
        return {"code":r.code,"short_url":f"/r/{r.code}","long_url":r.long_url}
    except ValueError as e: raise HTTPException(400, str(e))

@app.get("/r/{code}")
def redirect(code: str):
    try:
        r = service.resolve(code)
        return Response(status_code=307, headers={"Location": r.long_url})
    except KeyError as e: raise HTTPException(404, str(e))

@app.get("/api/v1/urls/{code}/analytics")
def analytics(code: str):
    try: return service.analytics(code)
    except KeyError as e: raise HTTPException(404, str(e))

@app.post("/api/v1/workflows/{scenario}")
def workflow(scenario: str, approved: bool = False):
    mapping={"greenfield":greenfield_stages,"brownfield":brownfield_stages,"ambiguous":ambiguous_stages}
    if scenario not in mapping: raise HTTPException(404,"Unknown scenario")
    run=orchestrator.execute(scenario,mapping[scenario](),{"human_approved":approved})
    return {"run_id":run.run_id,"state":run.state,"completed":run.completed,"failed":run.failed,"context":run.context}

@app.get("/api/v1/workflows/{run_id}")
def workflow_status(run_id: str):
    run=orchestrator.runs.get(run_id)
    if not run: raise HTTPException(404,"Run not found")
    return vars(run)

@app.get("/api/v1/audit")
def audit(): return [vars(e) for e in orchestrator.audit]

@app.get("/api/v1/metrics")
def metrics():
    m=dict(orchestrator.metrics); vals=m.pop("latency_ms"); m["avg_latency_ms"]=round(sum(vals)/len(vals),2) if vals else 0; return m
