from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

@dataclass
class UrlRecord:
    code: str
    long_url: str
    created_at: str = field(default_factory=utc_now)
    click_count: int = 0
    active: bool = True

@dataclass
class AuditEvent:
    event_type: str
    run_id: str
    stage: str
    message: str
    timestamp: str = field(default_factory=utc_now)
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass
class WorkflowRun:
    run_id: str
    scenario: str
    state: str = "CREATED"
    completed: list[str] = field(default_factory=list)
    failed: list[str] = field(default_factory=list)
    decisions: list[str] = field(default_factory=list)
    context: dict[str, Any] = field(default_factory=dict)
