from __future__ import annotations
import time, uuid
from dataclasses import dataclass
from typing import Callable
from .models import AuditEvent, WorkflowRun
from .governance import PolicyGuard

@dataclass
class Stage:
    name: str
    deps: list[str]
    action: Callable[[WorkflowRun], None]
    high_impact: bool = False
    max_retries: int = 2

class AgenticOrchestrator:
    """Stateful DAG executor with gates, bounded retry, rollback and safe-stop."""
    def __init__(self, policy: PolicyGuard):
        self.policy = policy
        self.audit: list[AuditEvent] = []
        self.metrics = {"success": 0, "runs": 0, "retries": 0, "rollbacks": 0, "safe_stops": 0, "latency_ms": []}
        self.runs: dict[str, WorkflowRun] = {}

    def _audit(self, run, typ, stage, msg, **metadata):
        self.audit.append(AuditEvent(typ, run.run_id, stage, msg, metadata=metadata))

    def execute(self, scenario: str, stages: list[Stage], context: dict) -> WorkflowRun:
        run = WorkflowRun(uuid.uuid4().hex[:12], scenario, context=dict(context))
        self.runs[run.run_id] = run
        self.metrics["runs"] += 1
        started = time.perf_counter()
        snapshots: dict[str, dict] = {}
        try:
            self._audit(run, "RUN_STARTED", "orchestrator", "Execution started", scenario=scenario)
            remaining = {s.name: s for s in stages}
            while remaining:
                ready = [s for s in remaining.values() if all(d in run.completed for d in s.deps)]
                if not ready:
                    raise RuntimeError("DAG deadlock: unresolved dependencies")
                # Independent stages are eligible for parallelism; this prototype executes them
                # deterministically in a batch so audit ordering remains reproducible.
                for stage in sorted(ready, key=lambda x: x.name):
                    gate = self.policy.check(stage.name, run.context)
                    self._audit(run, "GATE_EVALUATED", stage.name, gate.reason, allowed=gate.allowed)
                    if stage.high_impact and not run.context.get("human_approved"):
                        run.state = "WAITING_FOR_APPROVAL"
                        self.metrics["safe_stops"] += 1
                        self._audit(run, "SAFE_STOP", stage.name, gate.reason)
                        return run
                    if not gate.allowed:
                        raise PermissionError(gate.reason)
                    snapshots[stage.name] = dict(run.context)
                    last_error = None
                    for attempt in range(stage.max_retries + 1):
                        try:
                            self._audit(run, "STAGE_STARTED", stage.name, "Agent started", attempt=attempt + 1)
                            stage.action(run)
                            run.completed.append(stage.name)
                            self._audit(run, "STAGE_COMPLETED", stage.name, "Agent completed")
                            last_error = None
                            break
                        except Exception as exc:
                            last_error = exc
                            if attempt < stage.max_retries:
                                self.metrics["retries"] += 1
                                self._audit(run, "RETRY", stage.name, str(exc), attempt=attempt + 1)
                            else:
                                break
                    if last_error:
                        run.failed.append(stage.name)
                        self._audit(run, "ROLLBACK", stage.name, "Stage failed; restoring stage snapshot")
                        run.context = snapshots[stage.name]
                        self.metrics["rollbacks"] += 1
                        raise last_error
                    del remaining[stage.name]
            run.state = "SUCCEEDED"
            self.metrics["success"] += 1
            self._audit(run, "RUN_COMPLETED", "orchestrator", "Execution completed")
            return run
        except Exception as exc:
            run.state = "FAILED"
            run.context["error"] = str(exc)
            self._audit(run, "RUN_FAILED", "orchestrator", str(exc))
            return run
        finally:
            self.metrics["latency_ms"].append(round((time.perf_counter()-started)*1000, 2))

    def replan(self, run_id: str, changed_context: dict) -> WorkflowRun:
        run = self.runs[run_id]
        run.context.update(changed_context)
        run.decisions.append("REPLAN: upstream output changed; downstream gates must be re-evaluated")
        self._audit(run, "REPLAN", "orchestrator", "Context changed; re-planning requested", changed=changed_context)
        return run
