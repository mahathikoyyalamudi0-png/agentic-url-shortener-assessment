from __future__ import annotations
from .orchestrator import Stage

def greenfield_stages():
    return [
        Stage("requirements", [], lambda r: r.context.update(requirements="normalized: create/resolve/analytics")),
        Stage("architecture", ["requirements"], lambda r: r.context.update(architecture="API -> service -> store; orchestration DAG")),
        Stage("implementation", ["architecture"], lambda r: r.context.update(code_generated=True)),
        Stage("testing", ["implementation"], lambda r: r.context.update(test_failures=0, tests="unit + integration")),
        Stage("documentation", ["testing"], lambda r: r.context.update(docs_generated=True)),
        Stage("release", ["testing", "documentation"], lambda r: r.context.update(release_ready=True), high_impact=True),
    ]

def brownfield_stages():
    return [
        Stage("codebase_reasoning", [], lambda r: r.context.update(impacted_modules=["redirect", "analytics"])),
        Stage("change_design", ["codebase_reasoning"], lambda r: r.context.update(change="add analytics retention without breaking redirect")),
        Stage("implementation", ["change_design"], lambda r: r.context.update(code_generated=True)),
        Stage("regression_tests", ["implementation"], lambda r: r.context.update(test_failures=0)),
        Stage("release", ["regression_tests"], lambda r: r.context.update(release_ready=True), high_impact=True),
    ]

def ambiguous_stages():
    return [
        Stage("clarify", [], lambda r: r.context.update(ambiguities=["custom aliases collision policy", "analytics retention", "abuse controls"])),
        Stage("assumption_review", ["clarify"], lambda r: r.context.update(assumptions="safe defaults; approval required for policy-impacting changes")),
        Stage("risk_validation", ["assumption_review"], lambda r: r.context.update(security_findings=0, test_failures=0)),
        Stage("implementation", ["risk_validation"], lambda r: r.context.update(code_generated=True)),
    ]
