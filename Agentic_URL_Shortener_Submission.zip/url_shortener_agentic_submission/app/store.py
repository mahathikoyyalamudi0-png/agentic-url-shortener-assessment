from __future__ import annotations
from threading import RLock
from .models import UrlRecord

class UrlStore:
    def __init__(self):
        self._data: dict[str, UrlRecord] = {}
        self._lock = RLock()

    def put(self, record: UrlRecord) -> None:
        with self._lock:
            self._data[record.code] = record

    def get(self, code: str) -> UrlRecord | None:
        with self._lock:
            return self._data.get(code)

    def increment(self, code: str) -> UrlRecord | None:
        with self._lock:
            record = self._data.get(code)
            if record and record.active:
                record.click_count += 1
            return record

    def deactivate(self, code: str) -> UrlRecord | None:
        with self._lock:
            record = self._data.get(code)
            if record:
                record.active = False
            return record

    def snapshot(self) -> dict[str, UrlRecord]:
        with self._lock:
            return {k: UrlRecord(**vars(v)) for k, v in self._data.items()}
