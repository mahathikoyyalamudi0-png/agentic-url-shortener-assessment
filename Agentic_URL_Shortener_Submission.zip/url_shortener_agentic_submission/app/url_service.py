from __future__ import annotations
import hashlib
import re
from urllib.parse import urlparse
from .models import UrlRecord
from .store import UrlStore

class UrlService:
    CODE_RE = re.compile(r"^[A-Za-z0-9_-]{6,16}$")

    def __init__(self, store: UrlStore):
        self.store = store

    def validate_url(self, url: str) -> None:
        p = urlparse(url)
        if p.scheme not in {"http", "https"} or not p.netloc:
            raise ValueError("Only absolute HTTP/HTTPS URLs are accepted")

    def create(self, long_url: str, custom_alias: str | None = None) -> UrlRecord:
        self.validate_url(long_url)
        code = custom_alias or hashlib.sha256(long_url.encode()).hexdigest()[:8]
        if not self.CODE_RE.match(code):
            raise ValueError("Alias must be 6-16 characters: letters, digits, '_' or '-'")
        existing = self.store.get(code)
        if existing and existing.long_url != long_url:
            raise ValueError("Alias already belongs to another URL")
        record = existing or UrlRecord(code=code, long_url=long_url)
        self.store.put(record)
        return record

    def resolve(self, code: str) -> UrlRecord:
        record = self.store.increment(code)
        if not record or not record.active:
            raise KeyError("Short URL not found")
        return record

    def analytics(self, code: str) -> dict:
        record = self.store.get(code)
        if not record:
            raise KeyError("Short URL not found")
        return {"code": record.code, "long_url": record.long_url, "click_count": record.click_count, "active": record.active}
