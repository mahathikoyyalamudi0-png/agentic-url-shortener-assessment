# Architecture and Control Flow

## Core control-plane model
The orchestrator is a control plane, not a generic loop. Every stage has a name, dependencies, action, impact classification, and bounded retry policy. A stage can execute only when all dependencies have completed and its policy gate passes.

### State machine
`CREATED -> RUNNING -> WAITING_FOR_APPROVAL -> RUNNING -> SUCCEEDED`

Failure path:
`RUNNING -> FAILED`

A safe-stop is not a failure: it is a controlled terminal/intermediate state waiting for an explicit human decision.

## Dependency graph
For greenfield:
```text
requirements
     |
 architecture
     |
 implementation
     |
 testing ----+
     |        |
 documentation
     |        |
     +----> release [HUMAN APPROVAL]
```

The engine computes ready stages from dependency completion. The implementation intentionally groups independent ready stages as a batch so the same graph can later be backed by parallel workers.

## Governance
Policy is evaluated before every stage. Release, schema change, and production deletion are classified as high-impact. Security findings or test failures block release. The approval signal is explicit and auditable.

## Audit and observability
Every run records:
- run start/completion/failure
- gate decisions
- stage start/completion
- retries
- rollback
- safe-stop
- re-plan events

Metrics track run count, success count, retry count, rollback count, safe-stops, and latency. In production, these map naturally to OpenTelemetry spans, structured logs and SLO dashboards.

## Data plane
The URL service validates HTTP/HTTPS URLs, creates deterministic aliases by default, supports custom aliases, rejects collisions, tracks clicks, and exposes analytics. The store abstraction keeps persistence separate from business logic.

## Security controls
- Reject non-HTTP(S) URL schemes.
- Block known local/cloud metadata hosts in the policy layer.
- Require human approval for high-impact release operations.
- Block release when security findings or test failures exist.
- Preserve audit events for decisions and control-plane actions.

## Controlled autonomy
The agents may reason, create artifacts and execute stages, but they cannot cross the defined autonomy boundary. Release remains human-owned. This aligns with the assignment principle that agents operate within defined boundaries while humans retain oversight and final approval.
