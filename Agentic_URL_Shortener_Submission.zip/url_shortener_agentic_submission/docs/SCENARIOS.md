# Scenario Walkthroughs

## Greenfield
**Input:** Build a URL shortener with core APIs, analytics and reliability features.

**Decomposition:** requirements -> architecture -> implementation -> testing -> documentation -> release.

**Validation:** URL scheme validation, alias collision checks, redirect/analytics tests, release gate.

**Governance:** release safe-stops unless explicitly approved.

## Brownfield
**Input:** Add analytics retention to an existing shortener without changing redirect semantics.

**Reasoning:** identify redirect and analytics modules as impacted; isolate the change from the redirect path; add regression tests before release.

**Validation:** regression suite must pass; release requires approval.

**Rollback:** a failed implementation restores the stage context snapshot.

## Ambiguous
**Input:** “Add custom aliases and analytics.”

**Ambiguities surfaced:**
- What happens when two users choose the same alias?
- How long is analytics retained?
- Are aliases case-sensitive?
- What abuse/rate-limit controls are required?

**Safe assumptions:** deterministic collision rejection, explicit retention policy before production, and security validation before release.

**Why this matters:** the system does not allow an agent to silently convert ambiguity into irreversible production behavior.
