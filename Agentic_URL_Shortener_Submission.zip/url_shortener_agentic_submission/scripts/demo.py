from app.orchestrator import AgenticOrchestrator
from app.governance import PolicyGuard
from app.scenarios import greenfield_stages,brownfield_stages,ambiguous_stages

o=AgenticOrchestrator(PolicyGuard())
for name, stages, approved in [("greenfield",greenfield_stages(),False),("greenfield-approved",greenfield_stages(),True),("brownfield",brownfield_stages(),True),("ambiguous",ambiguous_stages(),False)]:
    run=o.execute(name,stages,{"human_approved":approved})
    print(name, run.state, run.completed, run.failed)
print("metrics",o.metrics)
print("audit_events",len(o.audit))
