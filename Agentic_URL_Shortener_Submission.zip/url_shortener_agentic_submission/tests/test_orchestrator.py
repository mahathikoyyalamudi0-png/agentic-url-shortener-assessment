from app.orchestrator import AgenticOrchestrator, Stage
from app.governance import PolicyGuard

def test_release_safe_stops_without_approval():
    o=AgenticOrchestrator(PolicyGuard())
    run=o.execute("greenfield", [Stage("release",[],lambda r:r.context.update(release=True),high_impact=True)], {})
    assert run.state == "WAITING_FOR_APPROVAL"

def test_retry_then_success():
    calls={"n":0}
    def flaky(r):
        calls["n"]+=1
        if calls["n"]<2: raise RuntimeError("transient")
    o=AgenticOrchestrator(PolicyGuard())
    run=o.execute("test",[Stage("implementation",[],flaky)],{})
    assert run.state=="SUCCEEDED" and o.metrics["retries"]==1

def test_failed_stage_rolls_back_context():
    def bad(r):
        r.context["unsafe_change"]=True
        raise RuntimeError("bad")
    o=AgenticOrchestrator(PolicyGuard())
    run=o.execute("test",[Stage("implementation",[],bad)],{"baseline":True})
    assert run.state=="FAILED" and "unsafe_change" not in run.context
