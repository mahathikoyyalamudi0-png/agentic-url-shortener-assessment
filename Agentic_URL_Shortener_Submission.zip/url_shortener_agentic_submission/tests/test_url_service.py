from app.store import UrlStore
from app.url_service import UrlService
import pytest

def test_create_resolve_and_analytics():
    s=UrlService(UrlStore()); r=s.create("https://example.com/a")
    assert s.resolve(r.code).long_url == "https://example.com/a"
    assert s.analytics(r.code)["click_count"] == 1

def test_invalid_url():
    with pytest.raises(ValueError): UrlService(UrlStore()).create("javascript:alert(1)")

def test_alias_collision():
    s=UrlService(UrlStore()); s.create("https://a.example", "custom1")
    with pytest.raises(ValueError): s.create("https://b.example", "custom1")
